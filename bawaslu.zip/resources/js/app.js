
// require ('./bootstrap');
// import 'bootstrap';
// import 'admin-lte';
// import 'overlayscrollbars';
// import 'jquery-mousewheel';
// import 'chart.js';
// import 'jquery';
// import 'datatables.net';
// import 'datatables.net-autofill';
// import 'datatables.net-autofill-bs4';
// import 'datatables.net-bs4';
// import 'datatables.net-buttons';
// import 'datatables.net-buttons-bs4';
// import 'datatables.net-responsive';
// import 'datatables.net-responsive-bs4';
// import 'pdfmake';

//bootstrap
import 'admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js';
//JQuery
import 'admin-lte/plugins/jquery/jquery.min.js';
//Data Tables
import 'admin-lte/plugins/datatables/jquery.dataTables.min.js';
import 'admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js';
import 'admin-lte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js';
import 'admin-lte/plugins/datatables-responsive/js/dataTables.responsive.min.js';
import 'admin-lte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js';
import 'admin-lte/plugins/datatables-buttons/js/dataTables.buttons.min.js';
import 'admin-lte/plugins/datatables-buttons/js/buttons.bootstrap4.min.js';
import 'admin-lte/plugins/jszip/jszip.min.js';
import 'admin-lte/plugins/pdfmake/pdfmake.min.js';
import 'admin-lte/plugins/pdfmake/vfs_fonts.js';
import 'admin-lte/plugins/datatables-buttons/js/buttons.html5.min.js';
import 'admin-lte/plugins/datatables-buttons/js/buttons.print.min.js';
import 'admin-lte/plugins/datatables-buttons/js/buttons.colVis.min.js';
import 'admin-lte/dist/js/adminlte.min.js';
